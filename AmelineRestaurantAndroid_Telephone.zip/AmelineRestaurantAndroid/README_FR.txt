AMELINE RESTAURANT — PROJET ANDROID
==================================

Ce dossier est un projet Android Studio qui embarque le jeu 2D Ameline Restaurant
dans une petite application Android (WebView). Le jeu fonctionne hors connexion :
la page et la photo du personnage sont intégrées dans l'application.

IMPORTANT
---------
Je ne peux pas compiler directement le fichier APK dans cet environnement :
le SDK Android et Gradle ne sont pas installés ici. Le projet est prêt à être
ouvert et compilé avec Android Studio sur un ordinateur.

COMMENT OBTENIR LE FICHIER APK
------------------------------
1. Installer Android Studio sur un ordinateur.
2. Décompresser AmelineRestaurantAndroid.zip.
3. Dans Android Studio, choisir "Open" et sélectionner le dossier
   AmelineRestaurantAndroid.
4. Attendre la synchronisation Gradle et l'installation des composants Android
   demandés (connexion Internet nécessaire la première fois).
5. Dans le menu, choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. À la fin, cliquer sur "locate" dans la notification Android Studio.

Le fichier APK de débogage sera normalement ici :
app/build/outputs/apk/debug/app-debug.apk

POUR INSTALLER SUR ANDROID
--------------------------
Transférer app-debug.apk sur le téléphone, l'ouvrir et autoriser l'installation
depuis cette source si Android le demande.

PARAMÈTRES
----------
Nom : Ameline Restaurant
Identifiant : com.ameline.restaurant
Version : 1.0
Android minimum : Android 6.0 (API 23)
Orientation : portrait
